<?php	
	session_start();
	require_once "./functions/admin.php";
	$title = "Edit publisher";
	require "./template/admin_header.php";
	require "./functions/database_functions.php";
	$conn = db_connect();
	
	// if save change happen
	if(!isset($_POST['save_change'])){
		echo "Something wrong!";
		exit;
	}
	
	$publisher_id = trim($_POST['publisher_id']);
	$publisher_name = trim($_POST['publisher_name']);

	$query = "UPDATE publisher SET publisher_name = '$publisher_name' WHERE publisher_id = '$publisher_id'";
	
	$result = mysqli_query($conn, $query);
	if(!$result){
		echo "Can't update data " . mysqli_error($conn);
		exit;
	} else {
		header("Location: admin_publisher.php");
	}
?>
<?php	
	session_start();
	require_once "./functions/admin.php";
	$title = "Edit author";
	require "./template/admin_header.php";
	require "./functions/database_functions.php";
	$conn = db_connect();
	
	// if save change happen
	if(!isset($_POST['save_change'])){
		echo "Something wrong!";
		exit;
	}
	
	$author_id = trim($_POST['author_id']);
	$author_name = trim($_POST['author_name']);

	$query = "UPDATE authors SET author_name = '$author_name' WHERE author_id = '$author_id'";
	
	$result = mysqli_query($conn, $query);
	if(!$result){
		echo "Can't update data " . mysqli_error($conn);
		exit;
	} else {
		header("Location: admin_author.php");
	}
?>
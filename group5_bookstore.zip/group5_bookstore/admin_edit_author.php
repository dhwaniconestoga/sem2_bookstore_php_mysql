<?php
	session_start();
	require_once "./functions/admin.php";
	$title = "Edit Author";
	require_once "./template/admin_header.php";
	require_once "./functions/database_functions.php";
	$conn = db_connect();

	if(isset($_GET['author_id'])){
		$author_id = $_GET['author_id'];
	} else {
		echo "Empty query!";
		exit;
	}

	if(!isset($author_id)){
		echo "Empty author! check again!";
		exit;
	}

	// get book data
	$query = "SELECT * FROM authors WHERE author_id = '$author_id'";
	$result = mysqli_query($conn, $query);
	if(!$result){
		echo "Can't retrieve data " . mysqli_error($conn);
		exit;
	}
	
	$row = mysqli_fetch_assoc($result);


?>
	<form method="post" action="edit_author.php" enctype="multipart/form-data">
		<input type="hidden" name="author_id" value="<?php echo $row['author_id'];?>">
		<table class="table">
			<tr>
				<th>Author Name</th>
				<td><input type="text" name="author_name" value="<?php echo $row['author_name'];?>"></td>
			</tr>
			
		</table>
		<input type="submit" name="save_change" value="Edit Changes" class="btn btn-primary">
		<input type="reset" value="Reset" class="btn btn-default">
	</form>
	<br/>
	<a href="admin_author.php" class="btn btn-success">Back</a>
<?php
	if(isset($conn)) {mysqli_close($conn);}
	require "./template/footer.php"
?>
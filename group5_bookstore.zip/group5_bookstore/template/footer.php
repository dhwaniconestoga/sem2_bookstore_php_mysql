      	<hr>

      	<footer>
        	<center>
            	<a href="#" target="_blank">Group5 Final Project BookStore 2022</a>
        	</center>
      	</footer>
    </div> <!-- /container -->

    <script type="text/javascript" src="./bootstrap/js/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="./bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>